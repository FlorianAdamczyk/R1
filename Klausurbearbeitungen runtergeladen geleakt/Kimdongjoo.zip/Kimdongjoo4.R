#Dongjoo Kim 7031799
##Aufgabe 4
#a
# Formel: H(ij)=1/(i+j-1)