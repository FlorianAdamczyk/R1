#Listner, Leon. 8108323
#Aufgabe 4

#a)
#Hij = 1/(i+j-1)

#b)
(H <- 1/matrix(c(1:4, 2:5, 3:6, 4:7), nrow=4))

#c)

